## ----setup, include = FALSE-------------------------------------------------------------------------------------------
options(width=120)
knitr::opts_chunk$set(
    collapse = FALSE,
    eval = TRUE,
    comment = " ",
    tidy.opts =list(width.cutoff=80),
    tidy = TRUE,
    size="small"
)

## ----eval=TRUE, include=FALSE-----------------------------------------------------------------------------------------
library(data.table)
library(jDMRgrid)

## ---------------------------------------------------------------------------------------------------------------------
samplefile1 <- system.file("extdata", "listFiles1.fn", package="jDMR")
fread(samplefile1, header = TRUE)

## ---------------------------------------------------------------------------------------------------------------------
samplefile2 <- system.file("extdata", "listFiles2.fn", package="jDMRgrid")
fread(samplefile2, header = TRUE)

## ----eval=TRUE, include=FALSE-----------------------------------------------------------------------------------------
#out.dir <- paste0("/myfolder/results/", Sys.getenv("LOGNAME"),"/")
out.dir.pop <- "/home/robert/jDMRgrid_test/folder_population"
out.dir.rep <- "/home/robert/jDMRgrid_test/folder_replicate"

## ----eval=FALSE, include=TRUE-----------------------------------------------------------------------------------------
#  library(jDMRgrid)
#  home_dir <- getwd()
#  out.dir.pop <- "/home/robert/jDMRgrid_test/folder_population"
#  out.dir.rep <- "/home/robert/jDMRgrid_test/folder_replicate"
#  samplefile <- system.file("extdata","listFiles2.fn", package="jDMRgrid")
#  
#  runjDMRgrid(
#      out.dir = paste0(out.dir.pop, '/grid'), window = 200, step = 50,
#      samplefiles = system.file("extdata", "listFiles1.fn", package="jDMRgrid"),
#      contexts = c("CG", "CHG", "CHH"), min.C = 10, mincov = 0,
#      include.intermediate = FALSE, runName = "Arabidopsis",
#      parallelApply = FALSE, #future_apply option enabled
#      numCores = NULL) #foreach loop option disabled
#  
#  runjDMRgrid(
#      out.dir = paste0(out.dir.rep, '/grid'), window = 200, step = 50,
#      samplefiles = system.file("extdata", "listFiles2.fn", package="jDMRgrid"),
#      contexts = c("CG", "CHG", "CHH"), min.C = 10, mincov = 0,
#      include.intermediate = TRUE, #include intermediate calls enabled
#      runName = "Arabidopsis", parallelApply = FALSE, # future_apply disabled
#      numCores = NULL) #foreach disabled

## ----eval=TRUE, include=FALSE-----------------------------------------------------------------------------------------

jDMR.out <- fread(paste0(out.dir.pop, '/grid/methimpute_p1.csv_CG.txt'))

## ----echo=FALSE-------------------------------------------------------------------------------------------------------
head(jDMR.out)

## ----eval=FALSE, include=TRUE-----------------------------------------------------------------------------------------
#  
#  makeDMRmatrix(
#      contexts = c("CG", "CHG", "CHH"), postMax.out = TRUE,
#      samplefiles = system.file("extdata", "listFiles1.fn", package="jDMRgrid"),
#      input.dir = paste0(out.dir.pop, '/grid'),
#      out.dir = paste0(out.dir.pop, '/matrix'), include.intermediate = FALSE)
#  
#  makeDMRmatrix(
#      contexts = c("CG", "CHG", "CHH"), postMax.out = TRUE,
#      samplefiles = system.file("extdata", "listFiles2.fn", package="jDMRgrid"),
#      input.dir = paste0(out.dir.rep, '/grid'),
#      out.dir = paste0(out.dir.rep, '/matrix'), include.intermediate = FALSE)
#  

## ----eval=TRUE, include=TRUE------------------------------------------------------------------------------------------
statecalls <- fread(
    paste0(out.dir.pop, "/matrix/CG_StateCalls.txt" , sep=""), header=TRUE)
head(statecalls)

## ----eval=TRUE, include=TRUE------------------------------------------------------------------------------------------
rcmethlvls <- fread(
    paste0(out.dir.pop, "/matrix/CG_rcMethlvl.txt" , sep=""), header = TRUE)
head(rcmethlvls)

## ----eval=TRUE, include=TRUE------------------------------------------------------------------------------------------
postMax <- fread(
    paste0(out.dir.pop, "/matrix/CG_postMax.txt" , sep=""), header = TRUE)
head(postMax)

## ----eval=FALSE, include=TRUE-----------------------------------------------------------------------------------------
#  split.groups(
#      samplefiles = system.file("extdata", "listFiles2.fn", package="jDMRgrid"),
#      input.dir = paste0(out.dir.rep, "/matrix"),
#      out.dir = paste0(out.dir.rep, "/matrix"))

## ----eval=FALSE, include=TRUE-----------------------------------------------------------------------------------------
#  
#  filterDMRmatrix(
#      epiMAF.cutoff = 0.33, replicate.consensus = NULL,
#      data.dir = paste0(out.dir.pop, "/matrix"), samplefiles = system.file(
#          "extdata", "listFiles1.fn", package="jDMRgrid"), if.mergingBins = FALSE)
#  
#  filterDMRmatrix(
#      epiMAF.cutoff = NULL, replicate.consensus = 0.8,
#      data.dir = paste0(out.dir.rep, "/matrix"), samplefiles = system.file(
#          "extdata", "listFiles2.fn", package="jDMRgrid"), if.mergingBins = FALSE)
#  
#  

## ----eval=TRUE, include=TRUE------------------------------------------------------------------------------------------
statecallsFiltered <- fread(
    paste0(out.dir.pop,"/matrix/CG_StateCalls-filtered.txt",sep=""),header=TRUE)
head(statecallsFiltered)

## ----eval=TRUE, include=TRUE------------------------------------------------------------------------------------------
rcmethlvlFiltered <- fread(
    paste0(out.dir.pop,"/matrix/CG_rcMethlvl-filtered.txt",sep=""),header=TRUE)
head(rcmethlvlFiltered)

## ----eval=FALSE, include=TRUE-----------------------------------------------------------------------------------------
#  
#  context.specific.DMRs(
#      samplefiles = system.file("extdata", "listFiles1.fn", package="jDMRgrid"),
#      output.dir = paste0(out.dir.pop, "/context_DMRs"),
#      input.dir = paste0(out.dir.pop, "/matrix"), if.filtered = FALSE)
#  
#  context.specific.DMRs(
#      samplefiles = system.file("extdata", "listFiles2.fn", package="jDMRgrid"),
#      output.dir = paste0(out.dir.rep, "/context_DMRs"),
#      input.dir = paste0(out.dir.rep, "/matrix"), if.filtered = FALSE)

## ----eval=FALSE, include=TRUE-----------------------------------------------------------------------------------------
#  
#  gff.file_promoters <- "~/jDMRgrid/jDMRgrid/toyData/TAIR10_promoters.gff3"
#  gff.file_TE <- "~/jDMRgrid/jDMRgrid/toyData/TAIR10_TE.gff3"
#  gff.file_genes <- "Z/jDMRgrid/jDMRgrid/toyData/TAIR10.gene.chr1.gff3"
#  
#  annotateDMRs(
#      gff.files = c(gff.file_promoters, gff.file_TE, gff.file_genes),
#      annotation = c("promoters", "TE", "gene"), #vec containing annotation types
#      input.dir = paste0(out.dir.pop, "/context_DMRs"), if.gff3 = FALSE,
#      out.dir = paste0(out.dir.pop, '/annotate_DMRs'))
#  
#  annotateDMRs(
#      gff.files = c(gff.file_promoters, gff.file_TE, gff.file_genes),
#      annotation = c("promoters", "TE", "gene"), #vec containing annotation types
#      input.dir = paste0(out.dir.rep, "/context_DMRs"), if.gff3 = FALSE,
#      out.dir = paste0(out.dir.pop, '/annotate_DMRs'))

## ----eval=TRUE, include=TRUE------------------------------------------------------------------------------------------
DMRcounts <- fread(
    paste0(out.dir.pop, "/annotate_DMRs/DMR-counts.txt", sep=""), header=TRUE)
DMRcounts

## ---------------------------------------------------------------------------------------------------------------------
sessionInfo()

